The code of our data processing and experiment are in folder /src/. The cleaned dataset are stored in folder /data/.

There are 3 datasets for test - dblp, lj, and youtube.

Programs can be run with r studio and Mathematica directly.